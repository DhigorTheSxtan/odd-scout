from pydantic import BaseModel, Field


class MarketOption(BaseModel):
    market_name: str
    selection: str
    odd: float


class FixtureCandidate(BaseModel):
    fixture_id: str
    home_team: str
    away_team: str
    league: str
    markets: list[MarketOption] = []


class BookmakerQuote(BaseModel):
    name: str
    total_odd: float
    is_best_choice: bool = False
    badge: str | None = None


class SelectionItem(BaseModel):
    fixture_id: str
    match: str
    market: str
    pick: str
    odd: float
    best_bookmaker: str = "Betano"
    justification: str


class BetOfTheDayData(BaseModel):
    combined_odd: float
    confidence_score: float
    reasoning: str
    best_bookmaker: BookmakerQuote
    bookmaker_comparison: list[BookmakerQuote]
    selections: list[SelectionItem]
    target_date: str | None = None
    total_jogos_dia: int = 0
    provedor: str = "OddScout Analytics"


class BetOfTheDayResponse(BaseModel):
    status: str
    badge_odd: str
    data: BetOfTheDayData | None = None
    message: str | None = None
    target_date: str | None = None
    total_jogos: int = 0
    provedor: str = "OddScout Analytics"
