from pydantic import BaseModel, Field


class LiveBestBookmaker(BaseModel):
    name: str = "Betano"
    odd: float


class LiveGameItem(BaseModel):
    fixture_id: str
    minute: str
    period: str
    league: str
    home_team: str
    away_team: str
    home_score: int = 0
    away_score: int = 0
    active_market: str
    best_bookmaker: LiveBestBookmaker
    ev_percentage: float = 0.0


class LiveOddsResponse(BaseModel):
    status: str
    total: int
    data: list[LiveGameItem] = []
