/**
 * Football Predictor AI - Frontend Dashboard Engine
 * Gestão de estado, filtros reativos, modal Raio-X e renderização analítica.
 */

// Estado da Aplicação
const state = {
    matches: [],
    leagues: new Map(),
    activeMarket: 'ALL',
    activeLeague: '',
    searchQuery: '',
    onlyHighConf: false,
    selectedDate: new Date().toISOString().split('T')[0],
    isLoading: false,
    currentModalMatch: null
};

// Elementos DOM
const dom = {
    datePicker: document.getElementById('date-picker'),
    btnRefresh: document.getElementById('btn-refresh'),
    refreshIcon: document.getElementById('refresh-icon'),
    apiStatusBadge: document.getElementById('api-status-badge'),
    statTotalGames: document.getElementById('stat-total-games'),
    statHighConf: document.getElementById('stat-high-conf'),
    statAvgCorners: document.getElementById('stat-avg-corners'),
    statAvgXg: document.getElementById('stat-avg-xg'),
    marketFilterContainer: document.getElementById('market-filter-container'),
    searchInput: document.getElementById('search-input'),
    leagueSelect: document.getElementById('league-select'),
    highConfToggle: document.getElementById('high-conf-toggle'),
    matchesGrid: document.getElementById('matches-grid'),
    emptyState: document.getElementById('empty-state'),
    btnClearFilters: document.getElementById('btn-clear-filters'),
    // Modal
    modalRaioX: document.getElementById('modal-raio-x'),
    modalCloseBtn: document.getElementById('modal-close-btn'),
    modalLeaguePill: document.getElementById('modal-league-pill'),
    modalVenueInfo: document.getElementById('modal-venue-info'),
    modalHomeLogo: document.getElementById('modal-home-logo'),
    modalHomeName: document.getElementById('modal-home-name'),
    modalAwayLogo: document.getElementById('modal-away-logo'),
    modalAwayName: document.getElementById('modal-away-name'),
    modalXgTotal: document.getElementById('modal-xg-total'),
    poissonMatrixBody: document.getElementById('poisson-matrix-body'),
    mktOver15: document.getElementById('mkt-over-15'),
    mktOver25: document.getElementById('mkt-over-25'),
    mktBtts: document.getElementById('mkt-btts'),
    mktHomeWin: document.getElementById('mkt-home-win'),
    modalCornerTotal: document.getElementById('modal-corner-total'),
    modalCornerHome: document.getElementById('modal-corner-home'),
    modalCornerAway: document.getElementById('modal-corner-away'),
    modalShotsTarget: document.getElementById('modal-shots-target'),
    modalShotsTotal: document.getElementById('modal-shots-total'),
    modalThrowTotal: document.getElementById('modal-throw-total'),
    modalThrowIntensity: document.getElementById('modal-throw-intensity'),
    modalSampleInfo: document.getElementById('modal-sample-info'),
    modalIsolationInfo: document.getElementById('modal-isolation-info')
};

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    initDatePicker();
    bindEvents();
    checkApiStatus();
    loadMatches();
    if (window.lucide) lucide.createIcons();
});

function initDatePicker() {
    dom.datePicker.value = state.selectedDate;
}

function bindEvents() {
    dom.datePicker.addEventListener('change', (e) => {
        state.selectedDate = e.target.value;
        loadMatches();
    });

    dom.btnRefresh.addEventListener('click', () => {
        loadMatches(true);
    });

    // Market tabs
    dom.marketFilterContainer.addEventListener('click', (e) => {
        const btn = e.target.closest('.market-btn');
        if (!btn) return;

        state.activeMarket = btn.dataset.market;
        
        // Atualizar estilos dos botões
        dom.marketFilterContainer.querySelectorAll('.market-btn').forEach(b => {
            b.classList.remove('bg-emerald-600', 'text-white', 'shadow-md', 'shadow-emerald-600/30');
            b.classList.add('bg-dark-700', 'text-gray-300');
        });
        btn.classList.remove('bg-dark-700', 'text-gray-300');
        btn.classList.add('bg-emerald-600', 'text-white', 'shadow-md', 'shadow-emerald-600/30');

        renderMatches();
    });

    // Pesquisa com debounce
    let searchTimeout;
    dom.searchInput.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            state.searchQuery = e.target.value.toLowerCase().trim();
            renderMatches();
        }, 250);
    });

    // Dropdown de Ligas
    dom.leagueSelect.addEventListener('change', (e) => {
        state.activeLeague = e.target.value;
        renderMatches();
    });

    // Toggle alta confiança
    dom.highConfToggle.addEventListener('change', (e) => {
        state.onlyHighConf = e.target.checked;
        renderMatches();
    });

    // Limpar filtros
    dom.btnClearFilters.addEventListener('click', resetFilters);

    // Modal close events
    dom.modalCloseBtn.addEventListener('click', closeModal);
    dom.modalRaioX.addEventListener('click', (e) => {
        if (e.target === dom.modalRaioX) closeModal();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && !dom.modalRaioX.classList.contains('hidden')) {
            closeModal();
        }
    });
}

function resetFilters() {
    state.activeMarket = 'ALL';
    state.activeLeague = '';
    state.searchQuery = '';
    state.onlyHighConf = false;

    dom.searchInput.value = '';
    dom.leagueSelect.value = '';
    dom.highConfToggle.checked = false;

    // Reset market buttons style
    dom.marketFilterContainer.querySelectorAll('.market-btn').forEach((b, idx) => {
        if (idx === 0) {
            b.classList.add('bg-emerald-600', 'text-white', 'shadow-md', 'shadow-emerald-600/30');
            b.classList.remove('bg-dark-700', 'text-gray-300');
        } else {
            b.classList.remove('bg-emerald-600', 'text-white', 'shadow-md', 'shadow-emerald-600/30');
            b.classList.add('bg-dark-700', 'text-gray-300');
        }
    });

    renderMatches();
}

async function checkApiStatus() {
    try {
        const res = await fetch('/api/status');
        const data = await res.json();
        const provedorOdds = data.sportsgameodds?.configured ? 'SportsGameOdds' : (data.oddspedia?.configured ? 'Odds Pedia' : 'Odds');
        if (data.status === 'online') {
            dom.apiStatusBadge.className = "px-2.5 py-0.5 text-xs font-semibold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1.5";
            dom.apiStatusBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-emerald-400"></span> ${provedorOdds} & IA Ativos`;
        } else {
            dom.apiStatusBadge.className = "px-2.5 py-0.5 text-xs font-semibold rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5";
            dom.apiStatusBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-amber-400"></span> Modo Resiliente`;
        }
    } catch (e) {
        dom.apiStatusBadge.className = "px-2.5 py-0.5 text-xs font-semibold rounded-full bg-red-500/20 text-red-300 border border-red-500/30 flex items-center gap-1.5";
        dom.apiStatusBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-red-400"></span> Offline`;
    }
}

async function loadMatches(forceRefresh = false) {
    if (state.isLoading) return;
    state.isLoading = true;

    dom.refreshIcon.classList.add('animate-spin');
    dom.matchesGrid.innerHTML = generateSkeletonCards(6);
    dom.emptyState.classList.add('hidden');

    try {
        const url = `/api/jogos-hoje?data=${state.selectedDate}&force_refresh=${forceRefresh}`;
        const res = await fetch(url);
        const json = await res.json();

        state.matches = json.partidas || [];

        // Atualizar lista de ligas
        state.leagues.clear();
        state.matches.forEach(m => {
            if (m.campeonato?.id && m.campeonato?.nome) {
                state.leagues.set(m.campeonato.id, m.campeonato.nome);
            }
        });
        populateLeagueSelect();

        // Atualizar contadores
        updateSummaryStats();

        // Renderizar
        renderMatches();
    } catch (err) {
        console.error("Erro ao carregar partidas:", err);
        dom.matchesGrid.innerHTML = `
            <div class="col-span-full glass-panel rounded-2xl p-8 text-center text-red-400 space-y-2">
                <i data-lucide="alert-triangle" class="w-10 h-10 mx-auto"></i>
                <h4 class="font-bold">Falha ao obter jogos do dia</h4>
                <p class="text-xs text-gray-400">${err.message || 'Verifique sua conexão ou configuração do servidor.'}</p>
            </div>
        `;
        if (window.lucide) lucide.createIcons();
    } finally {
        state.isLoading = false;
        dom.refreshIcon.classList.remove('animate-spin');
    }
}

function populateLeagueSelect() {
    const currentVal = dom.leagueSelect.value;
    dom.leagueSelect.innerHTML = `<option value="">Todos os Campeonatos</option>`;
    state.leagues.forEach((name, id) => {
        const opt = document.createElement('option');
        opt.value = id;
        opt.textContent = name;
        dom.leagueSelect.appendChild(opt);
    });
    dom.leagueSelect.value = currentVal;
}

function updateSummaryStats() {
    dom.statTotalGames.textContent = state.matches.length;

    let highConfCount = 0;
    let totalCorners = 0;
    let cornerMatchCount = 0;
    let totalXg = 0;
    let xgMatchCount = 0;

    state.matches.forEach(m => {
        const recs = m.recomendacoes || [];
        recs.forEach(r => {
            if (r.nivel === 'Alta') highConfCount++;
        });

        const corners = m.metricas_chave?.escanteios?.esperado_total;
        if (corners && corners > 0) {
            totalCorners += corners;
            cornerMatchCount++;
        }

        const xg = m.metricas_chave?.gols_esperados?.total;
        if (xg && xg > 0) {
            totalXg += xg;
            xgMatchCount++;
        }
    });

    dom.statHighConf.textContent = highConfCount;
    dom.statAvgCorners.textContent = cornerMatchCount > 0 ? (totalCorners / cornerMatchCount).toFixed(1) : '--';
    dom.statAvgXg.textContent = xgMatchCount > 0 ? (totalXg / xgMatchCount).toFixed(2) : '--';
}

function renderMatches() {
    const filtered = state.matches.filter(m => {
        // Filtro por Liga
        if (state.activeLeague && String(m.campeonato?.id) !== String(state.activeLeague)) {
            return false;
        }

        // Filtro de Busca (Nome de Mandante ou Visitante)
        if (state.searchQuery) {
            const home = (m.partida?.mandante?.nome || '').toLowerCase();
            const away = (m.partida?.visitante?.nome || '').toLowerCase();
            if (!home.includes(state.searchQuery) && !away.includes(state.searchQuery)) {
                return false;
            }
        }

        // Filtro por Mercado
        if (state.activeMarket !== 'ALL') {
            const hasMarket = m.recomendacoes?.some(r => r.mercado === state.activeMarket);
            if (!hasMarket) return false;
        }

        // Filtro Apenas Alta Confiança
        if (state.onlyHighConf) {
            const hasHigh = m.recomendacoes?.some(r => r.nivel === 'Alta');
            if (!hasHigh) return false;
        }

        return true;
    });

    if (filtered.length === 0) {
        dom.matchesGrid.innerHTML = '';
        dom.emptyState.classList.remove('hidden');
        if (window.lucide) lucide.createIcons();
        return;
    }

    dom.emptyState.classList.add('hidden');
    dom.matchesGrid.innerHTML = filtered.map((match, idx) => createMatchCard(match, idx)).join('');

    // Attach listeners aos botões do modal de Raio-X
    document.querySelectorAll('.btn-raio-x').forEach(btn => {
        btn.addEventListener('click', () => {
            const matchId = btn.dataset.matchId;
            const match = state.matches.find(m => String(m.partida?.id) === String(matchId));
            if (match) openModal(match);
        });
    });

    if (window.lucide) lucide.createIcons();
}

function createMatchCard(match, index) {
    const p = match.partida || {};
    const c = match.campeonato || {};
    const mk = match.metricas_chave || {};
    const recs = match.recomendacoes || [];
    const hasData = match.has_sufficient_data;

    // Horário formatado
    let timeFormatted = "--:--";
    if (p.data_hora) {
        try {
            const d = new Date(p.data_hora);
            timeFormatted = d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            timeFormatted = "--:--";
        }
    }

    // Seletor de recomendações relevantes para o filtro ativo
    const displayRecs = state.activeMarket === 'ALL'
        ? recs
        : recs.filter(r => r.mercado === state.activeMarket);

    return `
        <div class="glass-panel glass-panel-hover rounded-3xl p-5 flex flex-col justify-between border border-white/10 relative overflow-hidden group">
            
            <!-- Card Top: League & Status -->
            <div class="flex items-center justify-between pb-3 border-b border-white/10 text-xs">
                <div class="flex items-center gap-2 truncate max-w-[70%]">
                    ${c.logo ? `<img src="${c.logo}" alt="${c.nome}" class="w-4 h-4 object-contain">` : ''}
                    <span class="font-bold text-gray-300 truncate">${c.nome || 'Campeonato'}</span>
                </div>
                <div class="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                    <i data-lucide="clock" class="w-3 h-3"></i>
                    <span>${timeFormatted}</span>
                </div>
            </div>

            <!-- Teams Presentation -->
            <div class="py-4 space-y-3">
                <!-- Home Team -->
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <img src="${p.mandante?.logo || ''}" alt="${p.mandante?.nome}" class="w-8 h-8 object-contain drop-shadow" onerror="this.src='https://via.placeholder.com/32'">
                        <div>
                            <h4 class="font-extrabold text-sm text-white">${p.mandante?.nome || 'Mandante'}</h4>
                            <span class="text-[10px] text-blue-400 font-semibold uppercase tracking-wider">Casa</span>
                        </div>
                    </div>
                    <span class="text-xs font-mono font-bold text-gray-400">xG ${mk.gols_esperados?.home || '0.0'}</span>
                </div>

                <!-- Away Team -->
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-3">
                        <img src="${p.visitante?.logo || ''}" alt="${p.visitante?.nome}" class="w-8 h-8 object-contain drop-shadow" onerror="this.src='https://via.placeholder.com/32'">
                        <div>
                            <h4 class="font-extrabold text-sm text-white">${p.visitante?.nome || 'Visitante'}</h4>
                            <span class="text-[10px] text-purple-400 font-semibold uppercase tracking-wider">Fora</span>
                        </div>
                    </div>
                    <span class="text-xs font-mono font-bold text-gray-400">xG ${mk.gols_esperados?.away || '0.0'}</span>
                </div>
            </div>

            <!-- Metric Quick-Pills -->
            <div class="grid grid-cols-3 gap-2 py-2.5 border-t border-b border-white/5 text-center text-xs">
                <div class="bg-dark-700/50 rounded-xl p-1.5">
                    <span class="text-[10px] text-gray-400 block">Escanteios</span>
                    <span class="font-black text-amber-400">${mk.escanteios?.disponivel ? mk.escanteios.esperado_total : 'N/A'}</span>
                </div>
                <div class="bg-dark-700/50 rounded-xl p-1.5">
                    <span class="text-[10px] text-gray-400 block">Chutes Alvo</span>
                    <span class="font-black text-blue-400">${mk.finalizacoes?.disponivel ? mk.finalizacoes.no_alvo_esperado : 'N/A'}</span>
                </div>
                <div class="bg-dark-700/50 rounded-xl p-1.5">
                    <span class="text-[10px] text-gray-400 block">Laterais</span>
                    <span class="font-black text-purple-400">${mk.laterais?.disponivel ? mk.laterais.intensidade : 'N/A'}</span>
                </div>
            </div>

            <!-- Recommendations List -->
            <div class="py-3 space-y-2 flex-grow">
                <span class="text-[10px] font-bold text-gray-400 uppercase tracking-wider block">Oportunidades Analisadas</span>

                ${!hasData ? `
                    <div class="bg-dark-700/40 border border-white/5 rounded-xl p-3 text-center text-xs text-gray-400 space-y-1">
                        <span class="px-2 py-0.5 rounded text-[10px] bg-gray-500/20 text-gray-300 font-semibold">Dados Insuficientes</span>
                        <p class="text-[11px] text-gray-400">Sem amostragem consolidada de confrontos recentes para este torneio.</p>
                    </div>
                ` : displayRecs.length === 0 ? `
                    <p class="text-xs text-gray-500 italic">Nenhuma seleção atende aos critérios deste mercado.</p>
                ` : displayRecs.slice(0, 2).map(r => `
                    <div class="bg-dark-800/90 border border-white/10 rounded-xl p-2.5 space-y-1">
                        <div class="flex items-center justify-between">
                            <span class="text-[11px] font-bold text-gray-300 flex items-center gap-1.5">
                                <span class="w-1.5 h-1.5 rounded-full ${r.nivel === 'Alta' ? 'bg-emerald-400' : 'bg-amber-400'}"></span>
                                ${r.selecao}
                                ${r.odd_mercado ? `<span class="text-[10px] text-cyan-300 font-mono ml-1 font-bold">@${Number(r.odd_mercado).toFixed(2)}</span>` : ''}
                            </span>
                            <span class="text-[10px] font-black px-2 py-0.5 rounded-full ${r.nivel === 'Alta' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 glow-badge-high' : 'bg-amber-500/20 text-amber-300 border border-amber-500/30 glow-badge-moderate'}">
                                ${r.taxa_assertividade_percentual ? `${r.taxa_assertividade_percentual}% win` : `${r.confianca_porcentagem}%`}
                            </span>
                        </div>
                        <p class="text-[10px] text-gray-400 line-clamp-1">${r.justificativa}</p>
                    </div>
                `).join('')}
            </div>

            <!-- Bottom Action Button -->
            <div class="pt-2">
                <button data-match-id="${p.id}" class="btn-raio-x w-full py-2.5 rounded-xl bg-dark-700 hover:bg-emerald-600/90 active:scale-[0.99] text-xs font-bold text-gray-200 hover:text-white transition flex items-center justify-center gap-2 border border-white/5 hover:border-emerald-500/40">
                    <i data-lucide="microscope" class="w-3.5 h-3.5 text-emerald-400"></i>
                    <span>Abrir Raio-X da Partida</span>
                </button>
            </div>

        </div>
    `;
}

function openModal(match) {
    state.currentModalMatch = match;
    const p = match.partida || {};
    const c = match.campeonato || {};
    const mk = match.metricas_chave || {};
    const sm = match.sample_details || {};

    // Popula cabeçalho
    dom.modalLeaguePill.textContent = c.nome || 'Campeonato';
    dom.modalVenueInfo.textContent = `${p.estadio || 'Estádio'} • ${p.cidade || ''}`;
    
    // Times
    dom.modalHomeName.textContent = p.mandante?.nome || 'Mandante';
    dom.modalHomeLogo.src = p.mandante?.logo || '';
    dom.modalAwayName.textContent = p.visitante?.nome || 'Visitante';
    dom.modalAwayLogo.src = p.visitante?.logo || '';

    dom.modalXgTotal.textContent = mk.gols_esperados?.total || '0.0';

    // Matriz de Poisson
    renderPoissonMatrix(match.score_matrix || []);

    // Mercados de Poisson
    const mkt = mk.mercados_poisson || {};
    dom.mktOver15.textContent = `${mkt.over_1_5 || 0}%`;
    dom.mktOver25.textContent = `${mkt.over_2_5 || 0}%`;
    dom.mktBtts.textContent = `${mkt.btts_yes || 0}%`;
    dom.mktHomeWin.textContent = `${mkt.home_win || 0}%`;

    // Scouts profundos
    const corners = mk.escanteios || {};
    dom.modalCornerTotal.textContent = corners.disponivel ? corners.esperado_total : 'N/D';
    dom.modalCornerHome.textContent = corners.disponivel ? corners.esperado_mandante : 'N/D';
    dom.modalCornerAway.textContent = corners.disponivel ? corners.esperado_visitante : 'N/D';

    const shots = mk.finalizacoes || {};
    dom.modalShotsTarget.textContent = shots.disponivel ? shots.no_alvo_esperado : 'N/D';
    dom.modalShotsTotal.textContent = shots.disponivel ? shots.total_esperado : 'N/D';

    const throws = mk.laterais || {};
    dom.modalThrowTotal.textContent = throws.disponivel ? throws.esperado_total : 'N/D';
    dom.modalThrowIntensity.textContent = throws.disponivel ? throws.intensidade : 'Indisponível';

    // Amostragem
    dom.modalSampleInfo.textContent = `Amostragem: ${sm.home_matches_analyzed || 0} jogos Mandante / ${sm.away_matches_analyzed || 0} jogos Visitante`;
    dom.modalIsolationInfo.textContent = sm.isolated_home_away_split ? "Mando de campo estritamente isolado (Casa x Fora)" : "Mando de campo misto";

    // Exibir modal
    dom.modalRaioX.classList.remove('hidden');
    if (window.lucide) lucide.createIcons();
}

function closeModal() {
    dom.modalRaioX.classList.add('hidden');
}

function renderPoissonMatrix(matrix) {
    if (!matrix || matrix.length === 0) {
        dom.poissonMatrixBody.innerHTML = `<tr><td colspan="7" class="p-4 text-center text-gray-500">Matriz de placares indisponível.</td></tr>`;
        return;
    }

    let rowsHtml = '';
    for (let i = 0; i < matrix.length; i++) {
        rowsHtml += `<tr>`;
        rowsHtml += `<td class="p-2 font-bold text-gray-300 bg-dark-700/40 border border-white/5">${i}</td>`;
        
        for (let j = 0; j < matrix[i].length; j++) {
            const prob = matrix[i][j];
            
            // Intensidade do heatmap baseada na probabilidade (0% a ~15%)
            const intensity = Math.min(1.0, prob / 14.0);
            const bgRgba = `rgba(16, 185, 129, ${Math.max(0.04, intensity * 0.45)})`;
            const textColor = prob > 7 ? 'text-emerald-300 font-bold' : 'text-gray-400';

            rowsHtml += `
                <td class="poisson-cell p-2 border border-white/5 cursor-default ${textColor}" style="background-color: ${bgRgba}">
                    <span class="block">${prob}%</span>
                </td>
            `;
        }
        rowsHtml += `</tr>`;
    }

    dom.poissonMatrixBody.innerHTML = rowsHtml;
}

function generateSkeletonCards(count = 6) {
    let html = '';
    for (let i = 0; i < count; i++) {
        html += `
            <div class="glass-panel rounded-3xl p-5 border border-white/5 space-y-4 animate-pulse">
                <div class="flex justify-between items-center pb-3 border-b border-white/5">
                    <div class="h-4 bg-dark-700 rounded w-1/3"></div>
                    <div class="h-4 bg-dark-700 rounded w-16"></div>
                </div>
                <div class="space-y-3 py-2">
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full bg-dark-700"></div>
                            <div class="h-4 bg-dark-700 rounded w-28"></div>
                        </div>
                        <div class="h-3 bg-dark-700 rounded w-10"></div>
                    </div>
                    <div class="flex items-center justify-between">
                        <div class="flex items-center gap-3">
                            <div class="w-8 h-8 rounded-full bg-dark-700"></div>
                            <div class="h-4 bg-dark-700 rounded w-28"></div>
                        </div>
                        <div class="h-3 bg-dark-700 rounded w-10"></div>
                    </div>
                </div>
                <div class="h-10 bg-dark-700/50 rounded-xl"></div>
                <div class="h-16 bg-dark-700/70 rounded-xl"></div>
                <div class="h-9 bg-dark-700 rounded-xl"></div>
            </div>
        `;
    }
    return html;
}
