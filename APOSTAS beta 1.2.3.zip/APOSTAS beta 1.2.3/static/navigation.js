/**
 * navigation.js - Mapeamento de Rotas e Navegação Unificada do Dashboard
 * 
 * Centraliza o roteamento das modalidades e delega a NFL para o serviço SharpAPI.
 */

(function () {
  'use strict';

  const ROTAS_BACKEND = {
    futebol: '/api/partidas-analisadas',
    multiplas: '/api/multipla-segura-dia',
    nfl: '/api/nfl/jogos',
    nfl_games: '/api/nfl/games',
    nfl_status: '/api/nfl/status',
    esports: '/api/pandascore/partidas',
    esportes: '/api/sports'
  };

  /**
   * Navega para a visão de Futebol Americano alimentada pela SharpAPI
   * @param {string|null} data
   */
  function navegarParaNFL(data = null) {
    if (typeof window.atualizarCabecalhoSharpAPI === 'function') {
      window.atualizarCabecalhoSharpAPI();
    }
    if (typeof window.handleTabSwitch === 'function') {
      window.handleTabSwitch('nfl');
    }
    if (typeof window.carregarJogosNFL === 'function') {
      window.carregarJogosNFL('todas', 'todos', true, data);
    }
  }

  /**
   * Contrato de Configuração do Grid de Esportes na Sidebar
   * @type {Array<{id: string, name: string, icon: string, slug: string, active: boolean}>}
   */
  const SPORTS_GRID_CONFIG = [
    // Coluna 1
    { id: 'football', name: 'Futebol', icon: 'soccer-ball', slug: 'futebol', active: true },
    { id: 'basketball', name: 'Basquete', icon: 'basketball', slug: 'basquete', active: true },
    { id: 'baseball', name: 'Beisebol', icon: 'baseball', slug: 'beisebol', active: true },
    { id: 'volleyball', name: 'Vôlei', icon: 'volleyball', slug: 'volei', active: true },
    { id: 'rugby', name: 'Rugby', icon: 'rugby', slug: 'rugby', active: true },
    { id: 'nfl', name: 'NFL', icon: 'football-american', slug: 'nfl', active: true },
    
    // Coluna 2
    { id: 'nba', name: 'NBA', icon: 'basketball-nba', slug: 'nba', active: true },
    { id: 'mma_ufc', name: 'MMA/UFC', icon: 'combat-glove', slug: 'mma-ufc', active: true },
    { id: 'hockey', name: 'Hóquei', icon: 'hockey-stick', slug: 'hoquei', active: true },
    { id: 'handball', name: 'Handebol', icon: 'handball', slug: 'handebol', active: true },
    { id: 'afl', name: 'AFL', icon: 'afl-ball', slug: 'afl', active: true },
    { id: 'esports', name: 'Esports', icon: 'gamepad', slug: 'esports', active: true }
  ];

  window.NavigationManager = {
    rotas: ROTAS_BACKEND,
    sportsGridConfig: SPORTS_GRID_CONFIG,
    navegarParaNFL: navegarParaNFL
  };

  // Exportação global para consumo direto
  window.SPORTS_GRID_CONFIG = SPORTS_GRID_CONFIG;

})();
