/**
 * sidebar.js - Controlador de Navegação da Sidebar para SharpAPI
 * 
 * Desvincula a API-Sports e conecta os botões da NFL diretamente à SharpAPI oficial
 * através das rotas internas do backend (/api/nfl/jogos e /api/nfl/games).
 */

(function () {
  'use strict';

  const SHARPAPI_ENDPOINT_ROTA = '/api/nfl/jogos';
  const SHARPAPI_GAMES_ROTA = '/api/nfl/games';
  const SHARPAPI_STATUS_ROTA = '/api/nfl/status';
  const SHARPAPI_HOST_BADGE = 'api.sharpapi.io';
  const SHARPAPI_PROVIDER_BADGE = 'SHARPAPI OFICIAL';

  /**
   * Busca dados da NFL diretamente da SharpAPI via backend sem mocks
   * @param {string|null} dataStr - Data no formato YYYY-MM-DD (opcional)
   * @param {string} status - Filtro de status: 'todos', 'ao_vivo', 'pre_jogo', 'finalizado'
   * @param {boolean} forceRefresh - Se verdadeiro, ignora o cache
   */
  async function fetchNFLSharpAPI(dataStr = null, status = 'todos', forceRefresh = true) {
    try {
      let url = `${SHARPAPI_ENDPOINT_ROTA}?status=${encodeURIComponent(status)}&force_refresh=${forceRefresh}`;
      if (dataStr) {
        url += `&data=${encodeURIComponent(dataStr)}`;
      }

      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Falha HTTP ${response.status} ao conectar à SharpAPI`);
      }

      const payload = await response.json();
      return payload;
    } catch (err) {
      console.error('[SharpAPI NFL] Erro ao consumir serviço interno:', err);
      throw err;
    }
  }

  /**
   * Atualiza os elementos visuais do cabeçalho central para a identidade SharpAPI
   */
  function atualizarCabecalhoSharpAPI() {
    // Badge de Provedor Oficial
    const elBadgeOficial = document.getElementById('nfl-badge-oficial');
    if (elBadgeOficial) {
      elBadgeOficial.textContent = SHARPAPI_PROVIDER_BADGE;
      elBadgeOficial.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.2)]';
    }

    // Badge de Endpoint Host (api.sharpapi.io)
    const elBadgeEndpoint = document.getElementById('nfl-badge-endpoint');
    if (elBadgeEndpoint) {
      elBadgeEndpoint.innerHTML = `<span>⚡</span> ${SHARPAPI_HOST_BADGE}`;
      elBadgeEndpoint.className = 'px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-slate-800 text-cyan-300 border border-slate-700 flex items-center gap-1';
    }

    // Atualização nos sub-seletores de modalidades
    const elEsportesBadgeApi = document.getElementById('esportes-badge-api');
    const elEsportesBadgeEndpoint = document.getElementById('esportes-badge-endpoint');
    if (elEsportesBadgeApi && window.EsportesState && window.EsportesState.esporteAtivo === 'american-football') {
      elEsportesBadgeApi.textContent = SHARPAPI_PROVIDER_BADGE;
      if (elEsportesBadgeEndpoint) elEsportesBadgeEndpoint.textContent = SHARPAPI_HOST_BADGE;
    }
  }

  /**
   * Callback principal disparado ao clicar no botão "🏈 NFL" da barra lateral
   * @param {Event} [event] - Evento de clique opcional
   */
  function handleSidebarNFLClick(event) {
    if (event && event.preventDefault) {
      event.preventDefault();
    }

    // Atualiza cabeçalho visual com badges da SharpAPI
    atualizarCabecalhoSharpAPI();

    // Se existir a função de chaveamento global do painel, aciona a aba NFL
    if (typeof window.handleTabSwitch === 'function') {
      window.handleTabSwitch('nfl');
    } else if (typeof window.trocarAba === 'function') {
      window.trocarAba('nfl');
    }

    // Dispara a busca real via SharpAPI
    if (typeof window.carregarJogosNFL === 'function') {
      window.carregarJogosNFL('todas', 'todos', false);
    } else {
      fetchNFLSharpAPI().then(data => {
        console.log('[SharpAPI NFL] Jogos carregados:', data.total_jogos);
      });
    }
  }

  /**
   * Vincula os listeners de clique aos botões da NFL na sidebar esquerda
   */
  function initSidebarNFL() {
    // 1. Botão sob "Modalidades & Esportes" (Sub-item da grade de esportes)
    const subBtnNFL = document.getElementById('sidebar-sub-btn-nfl');
    if (subBtnNFL) {
      subBtnNFL.removeAttribute('onclick');
      subBtnNFL.addEventListener('click', handleSidebarNFLClick);
    }

    // 2. Botão de Atalho Primário da NFL
    const mainBtnNFL = document.getElementById('sidebar-btn-nfl');
    if (mainBtnNFL) {
      mainBtnNFL.removeAttribute('onclick');
      mainBtnNFL.addEventListener('click', handleSidebarNFLClick);
    }

    // 3. Botão sob "Modalidades & Esportes" (Sub-item Esports da grade)
    const subBtnEsports = document.getElementById('sidebar-sub-btn-esports');
    if (subBtnEsports) {
      subBtnEsports.addEventListener('click', () => {
        if (typeof window.handleTabSwitch === 'function') {
          window.handleTabSwitch('esports');
        }
      });
    }

    // 4. Sub-seletor central de esportes (Pill Futebol Americano)
    const pillNFL = document.getElementById('pill-sport-american-football');
    if (pillNFL) {
      pillNFL.addEventListener('click', () => {
        setTimeout(atualizarCabecalhoSharpAPI, 50);
      });
    }
  }

  // Auto-inicialização quando o DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSidebarNFL);
  } else {
    initSidebarNFL();
  }

  // Exportações para o escopo global
  window.fetchNFLSharpAPI = fetchNFLSharpAPI;
  window.handleSidebarNFLClick = handleSidebarNFLClick;
  window.atualizarCabecalhoSharpAPI = atualizarCabecalhoSharpAPI;

})();
