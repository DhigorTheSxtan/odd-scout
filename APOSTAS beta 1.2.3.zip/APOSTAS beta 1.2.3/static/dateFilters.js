/**
 * dateFilters.js - Utilitário Canônico de Filtros de Datas
 * Retorna as datas de Ontem, Hoje e Amanhã sincronizadas no fuso America/Sao_Paulo (BRT).
 * Calculadas DINAMICAMENTE em tempo real — nunca hardcoded.
 */
(function() {
  'use strict';

  function _calcDataBrasilia(offsetDias) {
    offsetDias = offsetDias || 0;
    var agora = new Date();
    // Obtém a data atual no fuso America/Sao_Paulo
    var spStr = agora.toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' }); // YYYY-MM-DD
    var parts = spStr.split('-').map(Number);
    var base = new Date(parts[0], parts[1] - 1, parts[2]);
    base.setDate(base.getDate() + offsetDias);
    var yy = base.getFullYear();
    var mm = String(base.getMonth() + 1).padStart(2, '0');
    var dd = String(base.getDate()).padStart(2, '0');
    return yy + '-' + mm + '-' + dd;
  }

  function getDateFilterPayload() {
    return {
      today: _calcDataBrasilia(0),
      tomorrow: _calcDataBrasilia(1),
      yesterday: _calcDataBrasilia(-1)
    };
  }

  if (typeof window !== 'undefined') {
    window.getDateFilterPayload = getDateFilterPayload;
    window._calcDataBrasilia = _calcDataBrasilia;
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { getDateFilterPayload, _calcDataBrasilia };
  }
})();

