"""
Roteador FastAPI para o Módulo de Odds Desreguladas (Radar EV+).
Disponibiliza rotas REST para consulta de oportunidades com valor esperado positivo (+EV).
"""

import logging
from typing import Optional, Dict, Any, Literal
from fastapi import APIRouter, Query, HTTPException

from services.oddspapi_ev_engine import oddspapi_ev_engine

logger = logging.getLogger("radar_ev_router")

router = APIRouter(tags=["Radar EV+"])


@router.get("/api/v1/radar-ev")
@router.get("/api/odds-desreguladas")
async def get_radar_ev(
    horizon: Literal["D0", "D1", "D2", "ALL"] = Query(
        "ALL",
        description="Janela temporal de interesse: 'D0' (Hoje), 'D1' (Amanhã), 'D2' (Depois de Amanhã) ou 'ALL'."
    ),
    min_edge: float = Query(
        2.0,
        ge=0.0,
        le=50.0,
        description="Margem percentual mínima de valor esperado (+EV %) ou discrepância."
    ),
    limit: int = Query(
        20,
        ge=1,
        le=100,
        description="Quantidade máxima de oportunidades a retornar."
    ),
    force_refresh: bool = Query(
        False,
        description="Forçar nova busca ignorando o cache temporário."
    )
) -> Dict[str, Any]:
    """
    Retorna o radar de cotações desreguladas (+EV).
    Compara as linhas da casa de referência (Pinnacle) com casas de varejo (Betano, Bet365, KTO, Betfair),
    removendo o overround para expor a probabilidade justa e ordenar pelo maior retorno líquido.
    """
    try:
        resultado = await oddspapi_ev_engine.obter_radar_ev(
            horizon=horizon,
            min_edge=min_edge,
            limit=limit,
            force_refresh=bool(force_refresh)
        )
        return resultado
    except Exception as exc:
        logger.error(f"[RadarEV] Erro ao consultar motor EV: {exc}", exc_info=True)
        # Responde HTTP 200 resiliente para garantir disponibilidade
        return {
            "status": "partial_success",
            "generated_at": "",
            "fuso_horario": "America/Sao_Paulo",
            "horizonte_solicitado": horizon,
            "min_edge_solicitado": min_edge,
            "total_desreguladas": 0,
            "top_opportunity": None,
            "items": [],
            "aviso": f"Modo de contingência ativo: {str(exc)}"
        }
