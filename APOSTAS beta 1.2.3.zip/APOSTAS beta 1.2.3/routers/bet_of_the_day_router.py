from fastapi import APIRouter, HTTPException
from models.bet_of_the_day import BetOfTheDayResponse
from services.bet_of_the_day_service import bet_of_the_day_service

router = APIRouter(prefix="/api/v1/bets", tags=["Bets"])


@router.get("/bet-of-the-day", response_model=BetOfTheDayResponse)
async def get_bet_of_the_day() -> BetOfTheDayResponse:
    try:
        data = await bet_of_the_day_service.get_or_generate_bet()
        return BetOfTheDayResponse(
            status="success",
            badge_odd=f"{data.combined_odd:.2f}X",
            data=data,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Falha ao processar a Bet do Dia: {exc}")
