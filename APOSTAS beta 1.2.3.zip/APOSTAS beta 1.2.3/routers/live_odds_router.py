from fastapi import APIRouter
from models.live_odds import LiveOddsResponse
from services.live_odds_service import live_odds_service

router = APIRouter(prefix="/api/v1/live", tags=["Live Odds"])


@router.get("/odds", response_model=LiveOddsResponse)
async def get_live_odds() -> LiveOddsResponse:
    games = await live_odds_service.get_live_odds()
    return LiveOddsResponse(
        status="success",
        total=len(games),
        data=games,
    )


# Alias para compatibilidade com chamadas do front
@router.get("/jogos-ao-vivo", response_model=LiveOddsResponse)
async def get_live_odds_alias() -> LiveOddsResponse:
    games = await live_odds_service.get_live_odds()
    return LiveOddsResponse(status="success", total=len(games), data=games)
