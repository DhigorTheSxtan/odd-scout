from datetime import datetime, timezone
from fastapi import APIRouter, Query
from services.fixtures_service import fixtures_service

router = APIRouter(prefix="/api/v1", tags=["Fixtures"])


def normalize_incoming_date(raw_date: str | None) -> str:
    if not raw_date or not raw_date.strip() or raw_date.lower() == "undefined":
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    d = raw_date.strip()
    if "/" in d:
        parts = d.split("/")
        if len(parts) == 3 and len(parts[2]) == 4:
            return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"
    if "-" in d:
        parts = d.split("-")
        if len(parts) == 3 and len(parts[0]) == 2 and len(parts[2]) == 4:
            return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"

    return d


@router.get("/leagues/summary")
async def get_leagues_summary(
    date: str | None = Query(default=None),
    data: str | None = Query(default=None),
):
    target_date = normalize_incoming_date(date or data)
    summary = await fixtures_service.get_leagues_summary(target_date)
    return {"status": "success", "date": target_date, "data": [s.model_dump() for s in summary]}


@router.get("/fixtures")
async def get_fixtures(
    league: str | None = Query(default=None),
    liga: str | None = Query(default=None),
    search: str | None = Query(default=None),
    q: str | None = Query(default=None),
    busca: str | None = Query(default=None),
    date: str | None = Query(default=None),
    data: str | None = Query(default=None),
):
    target_date = normalize_incoming_date(date or data)
    filter_param = league or liga or search or q or busca

    items = await fixtures_service.get_fixtures(target_date, filter_param)
    return {
        "status": "success",
        "date": target_date,
        "filter": filter_param,
        "total": len(items),
        "data": [item.model_dump() for item in items],
    }
