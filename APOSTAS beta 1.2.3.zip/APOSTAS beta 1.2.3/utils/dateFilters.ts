/**
 * utils/dateFilters.ts - Módulo TypeScript de Filtros de Datas
 * Calculadas DINAMICAMENTE em tempo real no fuso America/Sao_Paulo — nunca hardcoded.
 */

export interface DateFilterPayload {
  today: string;
  tomorrow: string;
  yesterday: string;
}

function _calcDataBrasilia(offsetDias: number = 0): string {
  const agora = new Date();
  const spStr = agora.toLocaleDateString('en-CA', { timeZone: 'America/Sao_Paulo' });
  const [y, m, d] = spStr.split('-').map(Number);
  const base = new Date(y, m - 1, d);
  base.setDate(base.getDate() + offsetDias);
  const yy = base.getFullYear();
  const mm = String(base.getMonth() + 1).padStart(2, '0');
  const dd = String(base.getDate()).padStart(2, '0');
  return `${yy}-${mm}-${dd}`;
}

export const getDataHoje = (): string => _calcDataBrasilia(0);
export const getDataAmanha = (): string => _calcDataBrasilia(1);
export const getDataOntem = (): string => _calcDataBrasilia(-1);

// Mantidos como getters para compatibilidade de uso como constantes
export const DATA_HOJE: string = _calcDataBrasilia(0);
export const DATA_AMANHA: string = _calcDataBrasilia(1);
export const DATA_ONTEM: string = _calcDataBrasilia(-1);

export const getDateFilterPayload = (): DateFilterPayload => {
  return {
    today: _calcDataBrasilia(0),
    tomorrow: _calcDataBrasilia(1),
    yesterday: _calcDataBrasilia(-1)
  };
};

