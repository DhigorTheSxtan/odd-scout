"""
Módulo re-exportador do scheduler em services/scheduler.py.
Garante compatibilidade total com importações de scheduler e services.scheduler.
"""

from scheduler import (
    TIMEZONE_BR,
    SSEBroadcastHub,
    sse_broadcast_hub,
    JobSchedulerService,
    job_scheduler,
    iniciar_agendador,
    parar_agendador,
)

__all__ = [
    "TIMEZONE_BR",
    "SSEBroadcastHub",
    "sse_broadcast_hub",
    "JobSchedulerService",
    "job_scheduler",
    "iniciar_agendador",
    "parar_agendador",
]
