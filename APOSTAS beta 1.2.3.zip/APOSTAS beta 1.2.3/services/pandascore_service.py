"""
Alias para importar pandascore_service a partir do pacote services.
"""
from pandascore_service import pandascore_service, PandaScoreService, fetch_esports_matches

__all__ = ["pandascore_service", "PandaScoreService", "fetch_esports_matches"]

