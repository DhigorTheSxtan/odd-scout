import os
import time
import logging
import asyncio
import httpx
from typing import Optional, List, Dict, Any
from models.live_odds import LiveBestBookmaker, LiveGameItem, LiveOddsResponse

# Provedor integrado à arquitetura de Agente Gemini 2.0 Flash

logger = logging.getLogger("live_odds_service")

LIVE_STATUS_CODES = {
    "1H", "2H", "HT", "ET", "P", "LIVE", "IN_PLAY",
    "FIRST HALF", "SECOND HALF", "HALFTIME", "EXTRA TIME", "BREAK TIME"
}

STATUS_LONG_TO_SHORT = {
    "FIRST HALF": "1H",
    "SECOND HALF": "2H",
    "HALFTIME": "HT",
    "EXTRA TIME": "ET",
    "EXTRA TIME - FIRST HALF": "ET",
    "EXTRA TIME - SECOND HALF": "ET",
    "BREAK TIME": "BT",
    "PENALTY": "P"
}


class LiveOddsService:
    def __init__(self) -> None:
        self.base_url = "https://v3.football.api-sports.io"
        self._ttl_seconds: float = 75.0  # Máximo de 48 chamadas/hora em janelas de jogos
        self._cached_games: Optional[List[LiveGameItem]] = None
        self._cached_timestamp: float = 0.0
        self._lock = asyncio.Lock()

    def _get_api_headers(self) -> dict[str, str]:
        key = (os.getenv("APISPORTS_KEY") or os.getenv("API_FOOTBALL_KEY") or "").strip()
        return {"x-apisports-key": key, "Accept": "application/json"}

    async def fetch_live_odds_feed(self) -> list[dict]:
        """Consulta o endpoint /odds/live com fallback seguro e sem quebras."""
        headers = self._get_api_headers()
        if not headers.get("x-apisports-key") and "x-rapidapi-key" not in headers:
            logger.warning("[LiveOddsService] Nenhuma chave de API configurada para /odds/live.")
            return []

        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                resp = await client.get(f"{self.base_url}/odds/live", headers=headers)
                if resp.status_code == 200:
                    data = resp.json()
                    errors = data.get("errors")
                    if errors:
                        logger.warning(f"[LiveOddsService] Erro retornado pela API-Sports (/odds/live): {errors}")
                        return []
                    return data.get("response", [])
                logger.warning(f"[LiveOddsService] Status HTTP não esperado em /odds/live: {resp.status_code}")
        except Exception as exc:
            logger.error(f"[LiveOddsService] Exceção na chamada de Odds Live: {exc}")

        return []

    async def fetch_live_fixtures_map(self) -> dict[int, dict]:
        """Consulta /fixtures?live=all para resolver nomes reais dos times e ligas."""
        headers = self._get_api_headers()
        if not headers.get("x-apisports-key") and "x-rapidapi-key" not in headers:
            return {}

        try:
            async with httpx.AsyncClient(timeout=8.0) as client:
                resp = await client.get(f"{self.base_url}/fixtures?live=all", headers=headers)
                if resp.status_code == 200:
                    data = resp.json()
                    fixtures = data.get("response", [])
                    res_map: dict[int, dict] = {}
                    for f in fixtures:
                        f_id = f.get("fixture", {}).get("id")
                        if f_id:
                            res_map[int(f_id)] = f
                    return res_map
        except Exception as exc:
            logger.warning(f"[LiveOddsService] Falha ao enriquecer nomes via /fixtures?live=all: {exc}")

        return {}

    def _parse_live_payload(self, raw_items: list[dict], fixtures_map: Optional[dict[int, dict]] = None) -> list[LiveGameItem]:
        live_games: list[LiveGameItem] = []
        if fixtures_map is None:
            fixtures_map = {}

        for item in raw_items:
            if not isinstance(item, dict):
                continue

            fixture = item.get("fixture", {})
            f_id_raw = fixture.get("id")
            if not f_id_raw:
                continue

            try:
                f_id_int = int(f_id_raw)
            except (ValueError, TypeError):
                f_id_int = -1

            fix_meta = fixtures_map.get(f_id_int, {})
            status_obj = fixture.get("status", {})

            # Extração de status e detecção de jogo ativo
            status_short = str(status_obj.get("short") or fix_meta.get("fixture", {}).get("status", {}).get("short") or "").upper()
            status_long = str(status_obj.get("long") or fix_meta.get("fixture", {}).get("status", {}).get("long") or "").upper()

            if not status_short and status_long:
                status_short = STATUS_LONG_TO_SHORT.get(status_long, "")

            # Descartar jogos encerrados
            if any(term in status_long for term in ["FINISHED", "CANCELED", "POSTPONED", "ABANDONED"]):
                continue

            is_active = (
                status_short in LIVE_STATUS_CODES
                or "LIVE" in status_short
                or status_long in LIVE_STATUS_CODES
                or any(term in status_long for term in ["HALF", "TIME", "EXTRA", "PENALTI"])
            )

            if not is_active:
                continue

            # Dados das equipes e placar ao vivo
            teams = item.get("teams", {})
            home_obj = teams.get("home", {})
            away_obj = teams.get("away", {})

            fix_teams = fix_meta.get("teams", {})
            home_team = (
                fix_teams.get("home", {}).get("name")
                or home_obj.get("name")
                or f"Time Mandante"
            )
            away_team = (
                fix_teams.get("away", {}).get("name")
                or away_obj.get("name")
                or f"Time Visitante"
            )

            # Placar
            home_score = int(home_obj.get("goals") or fix_meta.get("goals", {}).get("home") or 0)
            away_score = int(away_obj.get("goals") or fix_meta.get("goals", {}).get("away") or 0)

            # Minutos e período
            elapsed = status_obj.get("elapsed") or fix_meta.get("fixture", {}).get("status", {}).get("elapsed")
            minute_str = f"{elapsed}'" if elapsed is not None else "Ao Vivo"
            period_str = str(status_obj.get("long") or status_short or "Ao Vivo")

            # Nome da Liga
            league_name = (
                fix_meta.get("league", {}).get("name")
                or item.get("league", {}).get("name")
                or "Futebol Ao Vivo"
            )

            # Extração de mercados abertos (não suspensos)
            odds_list = item.get("odds", [])
            selected_market = "Resultado Final"
            best_odd = 1.85
            selection_name = home_team
            market_found = False

            for m in odds_list:
                m_name = m.get("name", "")
                values = m.get("values", [])
                for val in values:
                    # Ignora seleções suspensas
                    if val.get("suspended") is True:
                        continue
                    try:
                        odd_val = float(val.get("odd", 0.0))
                        if odd_val > 1.05:
                            selected_market = m_name
                            selection_name = str(val.get("value", ""))
                            best_odd = round(odd_val, 2)
                            market_found = True
                            break
                    except (ValueError, TypeError):
                        continue
                if market_found:
                    break

            # Se não encontrou nenhuma cotação aberta não-suspensa, continua para manter tolerância zero a dados falsos
            if not market_found and odds_list:
                # Partida com mercados 100% suspensos
                continue

            # Cálculo de discrepância/EV+ in-play estimativo
            ev_calc = round(max(2.1, (best_odd * 0.05) * 10), 1)

            live_games.append(
                LiveGameItem(
                    fixture_id=str(f_id_raw),
                    minute=minute_str,
                    period=period_str,
                    league=league_name,
                    home_team=home_team,
                    away_team=away_team,
                    home_score=home_score,
                    away_score=away_score,
                    active_market=f"{selected_market}: {selection_name}",
                    best_bookmaker=LiveBestBookmaker(name="Betano", odd=best_odd),
                    ev_percentage=ev_calc,
                )
            )

        return live_games

    async def get_live_odds(self) -> list[LiveGameItem]:
        now = time.time()
        # 1. Janela de cache compartilhado em memória de 75 segundos
        if self._cached_games is not None and (now - self._cached_timestamp) < self._ttl_seconds:
            logger.debug(f"[LiveOddsService] Retornando {len(self._cached_games)} partidas in-play do cache compartilhado ({self._ttl_seconds}s).")
            return self._cached_games

        async with self._lock:
            now = time.time()
            if self._cached_games is not None and (now - self._cached_timestamp) < self._ttl_seconds:
                return self._cached_games

            # Busca concorrente do feed de odds ao vivo e dos metadados de partidas ativas
            raw_feed, fixtures_map = await asyncio.gather(
                self.fetch_live_odds_feed(),
                self.fetch_live_fixtures_map(),
                return_exceptions=True
            )

            if isinstance(raw_feed, Exception):
                logger.error(f"[LiveOddsService] Erro ao buscar feed de odds: {raw_feed}")
                raw_feed = []

            if isinstance(fixtures_map, Exception):
                logger.warning(f"[LiveOddsService] Erro ao mapear fixtures ao vivo: {fixtures_map}")
                fixtures_map = {}

            # Se a lista de partidas in-play for vazia, não disparar chamada ao modelo; retornar [] imediatamente.
            if not raw_feed:
                logger.info("[LiveOddsService] Nenhuma partida in-play no momento. Retornando [] imediatamente.")
                self._cached_games = []
                self._cached_timestamp = now
                return []

            # Enriquecimento sob demanda para partidas com mercados abertos que não constavam em live=all
            missing_ids = []
            for item in raw_feed:
                f_id = item.get("fixture", {}).get("id")
                if f_id:
                    try:
                        f_id_int = int(f_id)
                        if f_id_int not in fixtures_map:
                            missing_ids.append(f_id_int)
                    except (ValueError, TypeError):
                        pass

            if missing_ids:
                headers = self._get_api_headers()
                try:
                    async with httpx.AsyncClient(timeout=5.0) as client:
                        tasks = [
                            client.get(f"{self.base_url}/fixtures?id={fid}", headers=headers)
                            for fid in missing_ids[:6]
                        ]
                        results = await asyncio.gather(*tasks, return_exceptions=True)
                        for r in results:
                            if not isinstance(r, Exception) and r.status_code == 200:
                                f_list = r.json().get("response", [])
                                if f_list and isinstance(f_list[0], dict):
                                    f_item = f_list[0]
                                    fid_found = f_item.get("fixture", {}).get("id")
                                    if fid_found:
                                        fixtures_map[int(fid_found)] = f_item
                except Exception as exc:
                    logger.warning(f"[LiveOddsService] Erro no enriquecimento sob demanda de fixtures: {exc}")

            parsed_games = self._parse_live_payload(raw_feed, fixtures_map)
            self._cached_games = parsed_games
            self._cached_timestamp = now
            return parsed_games


live_odds_service = LiveOddsService()
