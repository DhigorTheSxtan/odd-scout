import os
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any

logger = logging.getLogger("token_guard")

# Configuração Financeira (BRL)
PRICE_PER_1M_INPUT_USD = 0.075      # Gemini 2.0 Flash Input
PRICE_PER_1M_OUTPUT_USD = 0.30      # Gemini 2.0 Flash Output
BRL_USD_RATE = 5.50
DAILY_BUDGET_BRL = 2.00             # Limite orçamentário diário estrito
SAFETY_TRIP_BRL = 1.90              # Ponto de desarme preventivo (fallback determinístico)

TRACKER_FILE = Path("data/cache/token_cost_tracker.json")


class TokenGuard:
    """
    Disjuntor financeiro de proteção orçamentária para chamadas de IA.
    Monitora o consumo diário em BRL baseado na precificação do Gemini 2.0 Flash.
    Desarma preventivamente aos R$ 1,90 para assegurar que o teto diário de R$ 2,00 nunca seja ultrapassado.
    """

    def __init__(self, tracker_file: Path = TRACKER_FILE) -> None:
        self.tracker_file = tracker_file
        self.price_input_usd = PRICE_PER_1M_INPUT_USD
        self.price_output_usd = PRICE_PER_1M_OUTPUT_USD
        self.brl_usd_rate = BRL_USD_RATE
        self.daily_budget_brl = DAILY_BUDGET_BRL
        self.safety_trip_brl = SAFETY_TRIP_BRL

    def _get_today_str(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y-%m-%d")

    def _load_tracker(self) -> Dict[str, Any]:
        today = self._get_today_str()
        if not self.tracker_file.exists():
            init_data = {
                "date": today,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
                "estimated_cost_usd": 0.0,
                "estimated_cost_brl": 0.0,
                "calls_count": 0,
                "tripped": False
            }
            self._save_tracker(init_data)
            return init_data

        try:
            data = json.loads(self.tracker_file.read_text(encoding="utf-8"))
            if data.get("date") != today:
                # Novo dia: resetar tracker para R$ 0.00
                logger.info(f"[TokenGuard] Novo ciclo diário iniciado ({today}). Resetando tracker de custos.")
                data = {
                    "date": today,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "total_tokens": 0,
                    "estimated_cost_usd": 0.0,
                    "estimated_cost_brl": 0.0,
                    "calls_count": 0,
                    "tripped": False
                }
                self._save_tracker(data)
            return data
        except Exception as exc:
            logger.warning(f"[TokenGuard] Erro ao carregar tracker de tokens: {exc}")
            return {
                "date": today,
                "input_tokens": 0,
                "output_tokens": 0,
                "total_tokens": 0,
                "estimated_cost_usd": 0.0,
                "estimated_cost_brl": 0.0,
                "calls_count": 0,
                "tripped": False
            }

    def _save_tracker(self, data: Dict[str, Any]) -> None:
        try:
            self.tracker_file.parent.mkdir(parents=True, exist_ok=True)
            self.tracker_file.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as exc:
            logger.error(f"[TokenGuard] Erro ao persistir tracker de tokens: {exc}")

    def record_usage(self, input_tokens: int, output_tokens: int) -> float:
        """Registra uso de tokens e atualiza o custo estimado acumulado em BRL no dia."""
        tracker = self._load_tracker()
        cost_input_usd = (input_tokens / 1_000_000.0) * self.price_input_usd
        cost_output_usd = (output_tokens / 1_000_000.0) * self.price_output_usd
        cost_usd = cost_input_usd + cost_output_usd
        cost_brl = cost_usd * self.brl_usd_rate

        tracker["input_tokens"] += int(input_tokens)
        tracker["output_tokens"] += int(output_tokens)
        tracker["total_tokens"] = tracker["input_tokens"] + tracker["output_tokens"]
        tracker["estimated_cost_usd"] = round(tracker.get("estimated_cost_usd", 0.0) + cost_usd, 6)
        tracker["estimated_cost_brl"] = round(tracker.get("estimated_cost_brl", 0.0) + cost_brl, 4)
        tracker["calls_count"] = tracker.get("calls_count", 0) + 1

        if tracker["estimated_cost_brl"] >= self.safety_trip_brl:
            tracker["tripped"] = True
            logger.warning(
                f"[TokenGuard] 🚨 DISJUNTOR FINANCEIRO DESARMADO: Custo diário estimado R$ {tracker['estimated_cost_brl']:.2f} "
                f"atingiu o limite de segurança R$ {self.safety_trip_brl:.2f} (Teto R$ {self.daily_budget_brl:.2f}). Modo cache estrito ativado!"
            )

        self._save_tracker(tracker)
        return tracker["estimated_cost_brl"]

    def can_make_request(self) -> bool:
        """
        Retorna True se ainda houver cota financeira diária disponível (custo < R$ 1,90).
        Se estimated_cost_brl >= SAFETY_TRIP_BRL, registra alerta e ativa o modo cache estrito (rejeita chamadas externas).
        """
        tracker = self._load_tracker()
        estimated_cost_brl = float(tracker.get("estimated_cost_brl", 0.0))

        if estimated_cost_brl >= self.safety_trip_brl:
            logger.warning(
                f"[TokenGuard] 🚨 DISJUNTOR ATIVO: Custo de R$ {estimated_cost_brl:.2f} >= R$ {self.safety_trip_brl:.2f}. "
                f"Chamadas externas bloqueadas. Entregando exclusivamente dados locais em cache."
            )
            return False
        return True


token_guard = TokenGuard()
