import os
import re
from datetime import datetime, timezone
from pydantic import BaseModel, Field

from services.ai_analytics_service import obter_jogos_e_palpites_gemini


class MarketItem(BaseModel):
    market_name: str
    selection: str
    odd: float


class FixtureItem(BaseModel):
    id: str
    fixture_id: str
    home_team: str
    away_team: str
    league: str
    league_slug: str
    league_id: int | None = None
    country: str = ""
    kickoff: str
    horario: str
    status: str = "AGENDADO"
    markets: list[MarketItem] = []
    mercados: list[MarketItem] = []


class LeagueSummary(BaseModel):
    id: str
    name: str
    count: int


OFFICIAL_LEAGUES_CONFIG = {
    "premier-league": {"id": 39, "name": "Premier League", "country": "England"},
    "la-liga": {"id": 140, "name": "La Liga", "country": "Spain"},
    "serie-a": {"id": 135, "name": "Serie A", "country": "Italy"},
    "bundesliga": {"id": 78, "name": "Bundesliga", "country": "Germany"},
    "champions-league": {"id": 2, "name": "Champions League", "country": "World"},
    "brasileirao-serie-a": {"id": 71, "name": "Brasileirão Série A", "country": "Brazil"},
    "copa-libertadores": {"id": 13, "name": "Copa Libertadores", "country": "South America"},
    "copa-do-brasil": {"id": 73, "name": "Copa do Brasil", "country": "Brazil"},
    "liga-portugal": {"id": 94, "name": "Liga Portugal", "country": "Portugal"},
    "eredivisie": {"id": 88, "name": "Eredivisie", "country": "Netherlands"},
}

ID_TO_SLUG_MAP: dict[int, str] = {cfg["id"]: slug for slug, cfg in OFFICIAL_LEAGUES_CONFIG.items()}


def clean_str(val: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]", "", val).lower()


class FixturesService:
    def _identify_league_slug(self, league_id: int | None, league_name: str, country_name: str) -> str | None:
        if league_id and league_id in ID_TO_SLUG_MAP:
            return ID_TO_SLUG_MAP[league_id]

        l_clean = clean_str(league_name)
        c_clean = clean_str(country_name)

        if c_clean == "england" and l_clean == "premierleague":
            return "premier-league"
        if c_clean == "spain" and l_clean in ["laliga", "primera"]:
            return "la-liga"
        if c_clean == "italy" and l_clean == "seriea":
            return "serie-a"
        if c_clean == "germany" and l_clean == "bundesliga":
            return "bundesliga"
        if "championsleague" in l_clean and "women" not in l_clean:
            return "champions-league"
        if c_clean == "brazil" and l_clean in ["seriea", "brasileirao", "brasileiraoseriea"]:
            return "brasileirao-serie-a"
        if "libertadores" in l_clean:
            return "copa-libertadores"
        if c_clean == "brazil" and "copadobrasil" in l_clean:
            return "copa-do-brasil"
        if c_clean == "portugal" and l_clean in ["primeiraliga", "ligaportugal"]:
            return "liga-portugal"
        if c_clean == "netherlands" and l_clean == "eredivisie":
            return "eredivisie"

        return None

    def _matches_filter(self, f: FixtureItem, filter_query: str) -> bool:
        q_raw = filter_query.strip()
        q_clean = clean_str(q_raw)

        if str(f.league_id) == q_raw or f.id == q_raw:
            return True
        if q_clean == clean_str(f.league_slug) or q_clean == clean_str(f.league):
            return True
        if q_clean in ["seriea", "italy"]:
            return f.league_slug == "serie-a"
        if q_clean in ["brasileirao", "brasileiraoseriea", "brasil"]:
            return f.league_slug == "brasileirao-serie-a"
        if q_clean in clean_str(f.league) or q_clean in clean_str(f.home_team) or q_clean in clean_str(f.away_team):
            return True

        return False

    async def fetch_raw_games_from_api(self, target_date: str) -> list[dict]:
        try:
            res = await obter_jogos_e_palpites_gemini(data=target_date, force_refresh=False)
            if isinstance(res, dict):
                partidas = res.get("partidas") or res.get("jogos") or []
                if partidas:
                    return partidas
        except Exception as exc:
            print(f"[FixturesService] Erro ao obter dados do agente Gemini: {exc}")

        return []

    def _map_to_fixture_items(self, raw_items: list[dict], target_date: str) -> list[FixtureItem]:
        fixtures: list[FixtureItem] = []

        for item in raw_items:
            if not isinstance(item, dict):
                continue

            fixture_obj = item.get("fixture", {})
            raw_id = str(fixture_obj.get("id") or item.get("id") or "")
            if not raw_id:
                continue

            raw_date = str(fixture_obj.get("date") or item.get("data") or item.get("date") or "")
            if target_date and target_date not in raw_date:
                continue

            league_obj = item.get("league", {})
            raw_league_id = league_obj.get("id") or item.get("league_id") or (item.get("campeonato", {}).get("id") if isinstance(item.get("campeonato"), dict) else None)
            try:
                league_id_int = int(raw_league_id) if raw_league_id else None
            except (ValueError, TypeError):
                league_id_int = None

            league_name = str(league_obj.get("name") or item.get("liga") or item.get("league") or (item.get("campeonato", {}).get("nome") if isinstance(item.get("campeonato"), dict) else "") or "")
            country_name = str(league_obj.get("country") or item.get("pais") or item.get("country") or (item.get("campeonato", {}).get("pais") if isinstance(item.get("campeonato"), dict) else "") or "")

            slug = self._identify_league_slug(league_id_int, league_name, country_name)
            if not slug:
                continue

            teams_obj = item.get("teams", {})
            home = str(
                teams_obj.get("home", {}).get("name")
                or item.get("home_team")
                or item.get("times", {}).get("casa")
                or (item.get("mandante", {}).get("nome") if isinstance(item.get("mandante"), dict) else item.get("mandante"))
                or "Mandante"
            )
            away = str(
                teams_obj.get("away", {}).get("name")
                or item.get("away_team")
                or item.get("times", {}).get("fora")
                or (item.get("visitante", {}).get("nome") if isinstance(item.get("visitante"), dict) else item.get("visitante"))
                or "Visitante"
            )

            horario = "16:00"
            if "T" in raw_date:
                try:
                    horario = raw_date.split("T")[1][:5]
                except Exception:
                    pass
            elif item.get("horario"):
                horario = str(item.get("horario"))

            raw_status = fixture_obj.get("status", {}).get("short") or item.get("status") or "AGENDADO"
            status_label = "AGENDADO"
            if raw_status in ["1H", "2H", "HT", "LIVE"]:
                status_label = "AO VIVO"
            elif raw_status in ["FT", "AET", "PEN"]:
                status_label = "ENCERRADO"

            markets: list[MarketItem] = []
            for m in item.get("mercados") or item.get("markets") or []:
                m_name = m.get("nome") or m.get("name") or "1X2"
                for opt in m.get("opcoes") or m.get("bets") or m.get("values") or []:
                    markets.append(
                        MarketItem(
                            market_name=m_name,
                            selection=str(opt.get("palpite") or opt.get("value") or ""),
                            odd=float(opt.get("odd", 1.25)),
                        )
                    )

            if not markets and item.get("odds"):
                odds_obj = item.get("odds", {})
                if odds_obj.get("home_win"):
                    markets.append(MarketItem(market_name="1X2", selection=home, odd=float(odds_obj["home_win"])))
                if odds_obj.get("away_win"):
                    markets.append(MarketItem(market_name="1X2", selection=away, odd=float(odds_obj["away_win"])))
                if odds_obj.get("over_under", {}).get("over"):
                    markets.append(MarketItem(market_name="Total de Gols", selection=f"Mais de {odds_obj['over_under'].get('total', 2.5)}", odd=float(odds_obj["over_under"]["over"])))

            if not markets:
                markets = [
                    MarketItem(market_name="1X2", selection=home, odd=1.35),
                    MarketItem(market_name="Total de Gols", selection="Mais de 1.5", odd=1.20),
                ]

            official_name = OFFICIAL_LEAGUES_CONFIG[slug]["name"]

            fixtures.append(
                FixtureItem(
                    id=raw_id,
                    fixture_id=raw_id,
                    home_team=home,
                    away_team=away,
                    league=official_name,
                    league_slug=slug,
                    league_id=league_id_int,
                    country=country_name,
                    kickoff=horario,
                    horario=horario,
                    status=status_label,
                    markets=markets,
                    mercados=markets,
                )
            )

        return fixtures

    async def get_fixtures(self, target_date: str, filter_query: str | None = None) -> list[FixtureItem]:
        raw_games = await self.fetch_raw_games_from_api(target_date)
        fixtures = self._map_to_fixture_items(raw_games, target_date)

        if not filter_query or not filter_query.strip():
            return fixtures

        return [f for f in fixtures if self._matches_filter(f, filter_query)]

    async def get_leagues_summary(self, target_date: str) -> list[LeagueSummary]:
        all_fixtures = await self.get_fixtures(target_date)
        counts: dict[str, int] = {slug: 0 for slug in OFFICIAL_LEAGUES_CONFIG}
        for f in all_fixtures:
            if f.league_slug in counts:
                counts[f.league_slug] += 1

        return [
            LeagueSummary(id=slug, name=cfg["name"], count=counts[slug])
            for slug, cfg in OFFICIAL_LEAGUES_CONFIG.items()
        ]


fixtures_service = FixturesService()
