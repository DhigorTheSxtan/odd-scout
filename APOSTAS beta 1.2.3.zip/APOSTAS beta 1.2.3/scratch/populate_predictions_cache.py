import json
from pathlib import Path

source = Path("cache_diario_ia.json")
target = Path("data/cache/predictions_cache.json")
target.parent.mkdir(parents=True, exist_ok=True)

if source.exists():
    d = json.loads(source.read_text(encoding="utf-8"))
    palpites = d.get("palpites", {})
    items = []
    for k, v in palpites.items():
        home = v.get("home_team", "")
        away = v.get("away_team", "")
        items.append({
            "id": str(v.get("match_id", k)),
            "match": f"{home} vs {away}",
            "home_team": home,
            "away_team": away,
            "probabilidade": v.get("market_prob", 75.0),
            "mercado_recomendado": v.get("best_market") or v.get("recommended_market", ""),
            "top_3_bookmakers": v.get("top_3_bookmakers", []),
            "justificativa": v.get("reasoning", ""),
            "provedor": v.get("provedor", "gemini-2.0-flash")
        })
    target.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Successfully wrote {len(items)} items to {target}")
else:
    print("Source not found")
