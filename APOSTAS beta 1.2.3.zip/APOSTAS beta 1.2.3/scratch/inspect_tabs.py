with open("index.html", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        l = line.strip()
        if any(k in l for k in ['id="secao-', 'id="tab-', 'id="aba-', 'handleTabSwitch', 'trocarAba']):
            print(f"{i}: {l[:120]}")
